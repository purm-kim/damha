<header id="header">
		<div class="nav_wrap">
			<div class="img_wrap">
				<img src="/img/main/logo_horizon.jpg" alt="">
			</div>
			<ul class="nav">
				<li><a href="#">주요사업소개</a></li>
				<li><a href="#">상품구성</a></li>
				<li><a href="#">핵심강점과 경쟁력</a></li>
				<li><a href="#">주요 마케팅타겟</a></li>
			</ul>
		</div>
	</header>


	<div class="side_gnb">
		<!-- 상단에 붙어있는 헤더는 화면가로 넓이 100%를 헤더 높이만큼 가리게 되므로
			사이드 gnb 구성이 낫지 않을가,, 하는 생각 중...
			근데 구현을 못함 -->
	</div>